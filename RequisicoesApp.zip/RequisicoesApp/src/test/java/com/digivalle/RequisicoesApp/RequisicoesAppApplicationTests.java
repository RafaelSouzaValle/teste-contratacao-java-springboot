package com.digivalle.RequisicoesApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequisicoesAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
